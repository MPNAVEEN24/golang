package main
import "fmt"
import "io/ioutil"
import "strings"
func main() {
    fs,err :=ioutil.ReadFile("files2.txt")
    if err !=nil {
        fmt.Println("error is :",err)
    }
    var count int

    str :=string (fs)
    
    a:=strings.Split(str, " ")
    count1:=len(a)
    
    for i:=0;i<len(a);i++ {
        for _, value := range a[i] {
            switch value {
                            case 'a':
                            count++
                            case 'A':
                            count++

                            case 'e':
                            count++

                            case 'i':
                            count++

                            case 'I':
                                        count++

                                                case 'o':
                                                    count++

                                                case 'O':
                                                    count++

                                                case 'u':
                                                    count++

                                                case 'U':
                                                    count++

            }
        }

    }

fmt.Println(count1,count)
}