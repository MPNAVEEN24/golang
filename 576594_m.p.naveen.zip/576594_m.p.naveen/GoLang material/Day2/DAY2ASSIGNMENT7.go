package main
import "fmt"

func linearSearch(arrayzor [10]int, toFind int) int {
                for i, item := range arrayzor {
                                if item == toFind {
                                                return i
                                }
                }
                return -1
}

func main() {
                
                //fmt.Println("Enter the number of elements")
                //var n int
                //fmt.Scanln(&n)
                var arrayzor[10] int
                fmt.Println("Enter the elements")
                for i:=0;i<len(arrayzor);i++ {
                                fmt.Scanln(&arrayzor[i])
                }
                fmt.Println("Enter the search element")
                var toFind int
                fmt.Scanln(&toFind)
                index := linearSearch(arrayzor, toFind)
                if index == -1 {
                                fmt.Println("Number not found")
                } else {
                                fmt.Println("Index: ", index)
                                fmt.Println("arrayzor[", index, "] = ", arrayzor[index])
                }
}