package main
import (
      "fmt"
      "time"
     )
type Product struct {
id int
name string
mdate time.Time
}
func main() {
    now:=time.Now()
    fmt.Println(now)

    const format ="Jan 2, 2006"
    fmt.Println(now.Format(format))

    then1:=time.Date(2008,11,17,00,00,00,00,time.UTC)
 fmt.Println("======",then1)


    fmt.Println(then1.Format(format))
    fthen1:=then1.Format(format)   
    fmt.Println(fthen1)

    then:=time.Date(2009,11,17,00,00,00,00,time.UTC)
    fmt.Println(then)    

   //16 weeks, 7days aweek,24 hrs a day
    expDate:=then.Add(time.Hour*24*7*16.00)

    fmt.Println(expDate)    
    fmt.Println(now.Sub(expDate))
    fmt.Println(expDate.Before(now))
    fmt.Println(then.After(now))
    fmt.Println(then.After(then1))



p:=Product{id:1,name:"Laptop",mdate:time.Date(2018,05,10,00,00,00,00,time.UTC)}
fmt.Println(p)
fmt.Println(p.mdate.Year())
fmt.Println(p.mdate.Month())
fmt.Println(p.mdate.Day())
fmt.Println(p.mdate.Hour())
fmt.Println(p.mdate.Minute())
fmt.Println(p.mdate.Second())
fmt.Println(p.mdate.Nanosecond())




}



/*
 val:="May 22,2018"
 from:="January 2,2006"
 t,_:=time.Parse(from,val)
 fmt.Println(t)


*/

  




