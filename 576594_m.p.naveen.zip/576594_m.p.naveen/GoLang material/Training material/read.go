package main
import (
   "fmt"
   "os"
)
func main() {
   file,err :=os.Open("test.txt")
  if err!=nil {
     fmt.Println("error is :",err)
   
  }
  fs:=make([]byte,100)
    _,err=file.Read(fs)
  if err!=nil {
     fmt.Println("error is :",err)
  }
  fmt.Println(fs)
  str:=string(fs)
  fmt.Println(str)
  defer file.Close()
}












/*   size,err:=file.Stat()
  if err!=nil {
     fmt.Println("error is :",err)
    
  }
  fs:=make([]byte,size.Size())
    _,err=file.Read(fs)
  if err!=nil {
     fmt.Println("error is :",err)
     
  }
  str:=string(fs)
    fmt.Println(str)
*/
