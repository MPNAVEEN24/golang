
package main
import "fmt"
func main() {
 fmt.Println("enter digit (0..9)")
  var digit int
  fmt.Scanln(&digit)
  switch(digit) {
  case 0: fmt.Print("Zero \n")
  case 1: fmt.Print("One \n")
  case 2: fmt.Print("Two \n")
  default :  fmt.Print("Wrong data \n")
}
}
  