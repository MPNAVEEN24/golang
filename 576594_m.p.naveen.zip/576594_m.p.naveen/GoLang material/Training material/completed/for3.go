
package main
import "fmt"

func main() {
  a:=1
  for a<100 {
     a+=a
      fmt.Print(a,"\n")
}
 
}