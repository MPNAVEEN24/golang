package main
import "fmt"
type Student struct {
   name string
    age int
}
func(s Student) printdetails() {
fmt.Println(s.name,s.age)
}
func main() {
  s1:=Student {"Raj",20}
  fmt.Println(s1.name ,s1.age)
 s1.printdetails()
}