package main
import  (
   "fmt"
   "time"
   "math/rand"
   "sync" 
)
var wait sync.WaitGroup
var count int
var m sync.Mutex
func increment (s string) {
  for i:=0;i<10;i++ {
     m.Lock()
	x:=count
        x++
      time.Sleep(time.Duration(rand.Intn(4))*time.Millisecond)
      count =x
      fmt.Println(s,i,"Count:",count)
  m.Unlock()
  }
   wait.Done()
}
func main() {
    wait.Add(2)
    go increment("foo:")
    go increment("bar:")
    wait.Wait()
    fmt.Println("last  count value:",count)
    fmt.Println("Main function")
 }

