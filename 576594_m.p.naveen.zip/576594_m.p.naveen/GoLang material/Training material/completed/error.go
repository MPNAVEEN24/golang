package main
import   (
   "fmt"
   "errors"
   "math"
  
)
func sq(n float64) (float64,error) {
      if n<0 {
           return 0,errors.New("Negative number")
         }
   return math.Sqrt(n),nil
}
func main() {
 r,err:=sq(-64)
 if err!=nil {
   fmt.Println(err)
  } else {
   fmt.Println(r)
   }
}

