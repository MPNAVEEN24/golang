
package main
import "fmt"

func main() {
  a:=[]int{1,2,3,4,5}
   for i,value:=range a {
     if value==5 {
	fmt.Println("Index",i)
  }
}
}