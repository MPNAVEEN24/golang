package main
import "fmt"
import "time"
func hello() {
  fmt.Println("Go routine1")
 time.Sleep(5 * time.Second)
}
func main() {
   go hello()
   time.Sleep(1 * time.Second)
   fmt.Println("Main function")  
}
