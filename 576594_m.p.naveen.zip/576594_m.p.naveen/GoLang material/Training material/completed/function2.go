package main
import "fmt"
func fun(a int,b int) int { //return type of function
  return a+b    //function body
}
func main() {
  x:=fun(10,20)
  fmt.Println(x) //return value from function
fmt.Println(fun(56,78))
}