package main
import (
   "log"
   "os"
)
func main() {
     err:=os.Remove("testempty.txt")
    if err !=nil {
    log.Fatal(err)
  }
   
}

